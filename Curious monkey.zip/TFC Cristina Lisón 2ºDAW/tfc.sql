-- MariaDB dump 10.19  Distrib 10.4.24-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: tfc
-- ------------------------------------------------------
-- Server version	10.4.24-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `publicaciones`
--

DROP TABLE IF EXISTS `publicaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `publicaciones` (
  `id_pub` int(11) NOT NULL AUTO_INCREMENT,
  `usuario` int(11) NOT NULL,
  `fecha` date NOT NULL,
  `contenido` text NOT NULL,
  `imagen` varchar(200) NOT NULL,
  `comentarios` int(11) NOT NULL,
  PRIMARY KEY (`id_pub`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `publicaciones`
--

LOCK TABLES `publicaciones` WRITE;
/*!40000 ALTER TABLE `publicaciones` DISABLE KEYS */;
INSERT INTO `publicaciones` VALUES (1,4,'2010-05-22','Hello','',1),(2,4,'2010-05-22','Hola','',1),(3,4,'2010-05-22','Hola','',1),(5,4,'2010-05-22','Jello','',1),(6,4,'2010-05-22','Hola','',1),(7,4,'2010-05-22','Hola','',1),(8,4,'2010-05-22','d','',1),(9,4,'2010-05-22','x','',1),(10,4,'2017-05-22','Voy a rolear Strahd, quién se apunta? ','',1),(11,4,'2017-05-22','root','',1),(12,4,'2017-05-22','hola','',1),(13,4,'2017-05-22','Funciono c: ','',1),(14,5,'2017-05-22','publi admin','',1),(15,5,'2017-05-22','prueba 2','',1),(16,5,'2018-05-22','cvbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb','',1),(17,5,'2018-05-22','b','',1),(18,5,'2018-05-22','???','',1),(19,5,'2019-05-22','qwe','',1),(20,4,'2019-05-22','asdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasdasda','',1),(21,4,'2022-05-22','<<<','',1),(22,4,'2025-05-22','a','',1),(23,4,'2025-05-22','a','',1),(24,4,'2027-05-22','Hola Angy c: ','',1),(25,4,'2027-05-22','Im a Jobro and I like it Picasso','',1),(27,4,'0000-00-00','dsa','',1),(28,5,'2006-06-22','Hola','',1),(29,11,'0000-00-00','fecha','',1),(30,11,'0000-00-00','fecha 2','',1),(31,11,'2006-06-22','fecha 3','',1),(32,11,'2006-06-22','aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa','',1),(33,11,'2006-06-22','!!!','',1),(34,11,'2006-06-22','!!','',1),(35,11,'2006-06-22','!!','',1),(36,11,'2006-06-22','!!!!','',1),(37,11,'2006-06-22','!!!!!!','',1),(38,11,'2006-06-22','!!!!!!','',1),(39,11,'2006-06-22','$$','',1),(40,11,'2006-06-22','$$','',1),(41,11,'2006-06-22','$$$','',1),(42,11,'2006-06-22','wasda','',1),(43,11,'2006-06-22','asda','',1),(44,11,'2006-06-22','!','',1),(45,11,'2006-06-22','!','',1),(46,11,'2006-06-22','%','',1),(47,11,'2006-06-22','%','',1),(48,11,'2006-06-22','&','',1),(49,11,'2006-06-22','&','',1),(50,11,'2006-06-22','&','',1),(51,11,'2006-06-22','\"\"','',1),(52,11,'2006-06-22','\"\"','',1),(53,11,'2006-06-22','\'','',1),(54,11,'2006-06-22','\'','',1);
/*!40000 ALTER TABLE `publicaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuarios` (
  `id_use` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) NOT NULL,
  `usuario` varchar(100) NOT NULL,
  `contrasena` varchar(100) NOT NULL,
  `nacimiento` date NOT NULL,
  `avatar` varchar(200) NOT NULL,
  `email` varchar(100) NOT NULL,
  `sexo` varchar(100) NOT NULL,
  `fecha_reg` date NOT NULL,
  `bio` varchar(120) NOT NULL,
  PRIMARY KEY (`id_use`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuarios`
--

LOCK TABLES `usuarios` WRITE;
/*!40000 ALTER TABLE `usuarios` DISABLE KEYS */;
INSERT INTO `usuarios` VALUES (4,'root','root','63a9f0ea7bb98050796b649e85481845','0000-00-00','default.png','root@gmail.com','','2028-04-22','Prueba de bio con todos los caracteres disponibles aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa'),(9,'asdfqwert4532','qwe','76d80224611fc919a5d54f0ff9fba446','0000-00-00','default.png','qw@gmial.com','','2006-06-22',''),(10,'user1','user1','81dc9bdb52d04dc20036dbd8313ed055','0000-00-00','default.png','user1@gmail.com','','2006-06-22',''),(11,'danielito','Dan23','86a90d3baae38d2857540d98c1d2578b','0000-00-00','default.png','dan@gmail.com','','2006-06-22','Hello there');
/*!40000 ALTER TABLE `usuarios` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-06 22:21:52
