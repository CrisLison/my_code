<?php








function barraLateral(){
  


	
	?>

		<div class="contenedorLogo">
			<div class="logo">	
				<!-- LOGO MONO-->
				<img src="imgs/monkey.png" width="11%" style='margin-right: 3px;'>

				<div class="nombreLogo"> Curious Monkey </div>
			</div>
			<i class='bx bx-menu' id = "btn"></i>
			
		</div>

		<!----------------------------LISTA PARA LOS ENLACES------------------------------------->

		<ul class="listaNav">

			<!-------------------------BÚSQUEDA---------------------------------------->

			<li>
				
					<i class='bx bx-search' ></i>
					<form method="GET">
						<input type="text" name = 'usuarioBuscar' id = 'usuarioBuscar' placeholder="Search...">
						<button type="submit" name = "enviarUser" id="enviarUser"></button>


						<!-------------------------BÚSQUEDA USUARIO---------------------------------------->

						<?php

					$connect = conn();

					


							if(isset($_GET['enviarUser'])){

								$busqueda = $_GET['usuarioBuscar'];

								$consulta = $connect -> query("SELECT * FROM usuarios WHERE usuario = '$busqueda'");

								$use = mysqli_fetch_array($consulta);

								if ($use['id_use'] == true) {
									header("Refresh: 0; url = profile.php?cod=".$use['id_use']);
							
									
								} else {
									echo ('<script language="javascript">

													alert("La cuenta no existe");

												</script>');
									header("Refresh: 0; url = home.php");


								}

							}

								mysqli_close($connect);

						?>

					</form>
					<span class="herramientas">Search</span> 

			</li>
			<li></li>
			<!--------------------------HOME--------------------------------------->

			<li>
				<a href="./home.php">
					<i class='bx bx-home'></i>
					<span class="nombreLinks">Home</span>
				</a>
				<span class="herramientas">Home</span> 
			</li>

			<!--------------------------USUARIO--------------------------------------->

			<li>
				<a href="./profile.php?cod=<?php echo $_SESSION['id']; ?>">
					<i class='bx bx-user' ></i>
					<span class="nombreLinks">Profile</span>
				</a>
				<span class="herramientas">Profile</span> 
			</li>



			<!----------------------------------------------------------------->

			<li>
				<a href="ajustes.php">
					<i class='bx bx-cog' ></i>
					<span class="nombreLinks">Settings</span>
				</a>
				<span class="herramientas">Settings</span>

			</li>

			<!----------------------------------------------------------------->

		</ul>

		<!----------------------------------------------------------------->

		<div class="profileContent">
			<div class="perfil">
				<div class="detallesPerfil">
					<img src="imgs/<?php echo $_SESSION['avatar']; ?>"> 
					<div class="nombresPerfil">
						<div class="nombreUsuario"><?php echo $_SESSION['nombre']; ?></div>
						<div class="nombreCuenta"><?php echo "@".$_SESSION['cuenta']; ?></div>
					</div>
					
				</div>
			<!--------------------------LOGOUT--------------------------------------->
			<a href="php/logout.php" style="color: white;">
			<i class='bx bx-log-out' id="log_out"></i>
		</a>
			</div>
			
		</div>

<?php
}


function navBar($titulo){
	?>

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">


<nav class="navbar navbar-expand-lg navbar-light bg-light" style="background: none !important; border-bottom: 2px solid #777;" >
  <label class="navbar-brand" ><?php echo $titulo; ?></label>
  
</nav>
<?php
}

?>