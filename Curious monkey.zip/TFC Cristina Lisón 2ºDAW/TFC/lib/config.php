<?php
function conn(){
	$host = "localhost";
	$dbuser = "root";
	$dbpwd = "918787393z";
	$db = "tfc";

	$connect = new mysqli ($host, $dbuser, $dbpwd, $db);

	return $connect;

	if($connect -> connect_errno){
		die ("No se ha podido conectar con la base de datos.");
	} 
}
?>