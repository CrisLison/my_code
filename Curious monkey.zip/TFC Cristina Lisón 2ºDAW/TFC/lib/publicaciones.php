<?php

$connect = conn();

$publisMostradas = 105;

//SE RECOGEN TODAS LAS PUBLICACIONES REALIZADAS POR TODOS LOS USUARIOS

$compag = (int)(!isset($_GET['pag'])) ? 1 : $_GET['pag'];






$vistas = "SELECT * FROM publicaciones ORDER BY id_pub DESC LIMIT ".(($compag - 1)*$publisMostradas)." , ".$publisMostradas;

$consulta = mysqli_query($connect, $vistas);

while ($lista = mysqli_fetch_array($consulta)){

	$userid = ($lista['usuario']);

	$usuarioPubli = $query = mysqli_query($connect, "SELECT * FROM usuarios WHERE id_use = '$userid'");
	$use = mysqli_fetch_array($usuarioPubli);
?>
	
	<div class="publicacion">
		<div class="contenidoPubli">
			<div class="datosUsuario">
				<a href="./profile.php?cod=<?php echo $lista['usuario']; ?>"><img src="imgs/<?php echo $use['avatar']; ?> " class = "imgPubli"></a>
				
				<a href="./profile.php?cod=<?php echo $lista['usuario'];?>" style = "text-decoration: none; color: black"><span class ="usuarioPubli"><?php echo $use['nombre']; ?></span></a>
				<span class ="cuentaPubli"> <?php echo '@'.$use['usuario']; ?></span>
				<span class="fechaPubli"><?php echo $lista['fecha']; ?></span>
			</div>
			<div class="contenido">	
				<p><?php echo $lista['contenido']; ?></p>
			</div>
			<div class="herramientas">
				<i class='bx bx-like'></i><span>I like it!</span>
				<i class='bx bx-dislike'></i><span>I dont like it!</span>
				<i class='bx bx-share' ></i><span>Share!</span>
			</div>
		</div>
	</div>
	<div class = "linea" style="margin-top: 0 !important; margin-bottom: 10px !important;"></div>



<?php
}
//Validamos el incremento para que no genere un error de consulta



