
<?php

session_start();
include ('lib/config.php');
include ('lib/side.php');

if (!isset($_SESSION['cuenta'])){

	header("Location: regitro.php");

}
$codUser = 0;

if (isset($_GET['cod'])){

	$codUser = ($_GET['cod']);
}

?>	


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="styles/menu.css">
	<link rel="stylesheet" type="text/css" href="styles/publicacionesPerfilStyle.css">
		<link rel="stylesheet" type="text/css" href="styles/profile.css">
	<title>Profile page</title>
	<link rel="shortcut icon" href="imgs/logo.png">
	<!-- LINK IMPORTACIÓN ICONOS DESDE BOXICONS-->
	<link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>

	<!-- SCROLL	-->
	 <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.3/jquery.min.js"></script>

	<script src="//unpkg.com/jscroll/dist/jquery.jscroll.min.js"></script>
	<script type="text/javascript" src = js/jquery.jscroll.js></script>



</head>
<body style="overflow-y: scroll; background: white">

	<?php

		$connect = conn();
		
		

			$id = ($_SESSION['id']);

			

			$usuarioInfo = $query = mysqli_query($connect, "SELECT * FROM usuarios WHERE id_use = '$codUser'");
			
			$resultSet = $query2 = mysqli_query($connect, "SELECT COUNT(id_pub) FROM publicaciones WHERE usuario = '$codUser'");

			$count = mysqli_fetch_array($resultSet);

			$use = mysqli_fetch_array($usuarioInfo);

		

	
	  ?>

	<div class="menuLateral">
		<?php
			barraLateral();
		  ?>
	</div>
	
	<div class="homeContent">



		<div class="postsPerfil" style="z-index: 0;">
	

		<div>
			<?php
			if($codUser != $id){
				navBar($use['nombre'].' screechs');
			} else {
				navBar('My screechs');
			}
			?>
		</div>

		<?php require_once 'lib/publicacionesPerfil.php'; ?>


		</div>
		
		<div class="separador">
			
		</div>

		<div class="infoUsuario" style="z-index: 2;">
			<div class="imgFondoUsuario" style="float: right; position: fixed;">
				<img src="imgs/fondoPrueba.jpg">
			</div>
			
			<div class="pfpUsaurio" style="float: right; position: fixed; margin-top: 150px !important;">
				<img src="imgs/<?php echo $use['avatar'];?>" style="float: right; position: fixed;" >
			</div>


			<div class="datosUsuarioPerfil"style="float: right; position: fixed;  margin-top: 250px; height: 100%" >

				<?php
				if($codUser != $id){
				?>
					<div style="height: 5%; display: flex; background: none;">
						
							
					</div>

				<?php
				} else {
				?>
					<div class="ajustesUsuario">
						<a href="ajustes.php">
							<i class='bx bx-cog'></i>
						</a>
					</div>
				<?php
				}
				?>

				<div class="nombresUsuario">
					<span><?php echo $use['nombre']; ?></span>
					<br>
					<span class="cuentaUsuario"><?php echo '@'.$use['usuario']; ?></span>
				</div>
				
				<div class="bioUsuario">
					<?php 
					if (!empty($use['bio']) ) {
						
					?>
					<span><?php echo $use['bio']; ?></span>

					<?php 
					} else if (!isset($use['bio']) || ($use['bio']) == ""){
					 ?>

					 	<h3><a href="ajustes.php" style="text-decoration: none; margin-left: 5%; color: black;">Click me to write your new bio!</a></h3>

					 <?php
					}
					?>
				</div>

					<!-- DIV FOLLOWERS -->
				<div class="followers">
					<div class="data">
						<ul>
							<li>
								<?php

									echo $count[0];

								?>
								<span>Screechs</span>
							</li>
							<li>
								1,119
								<span>Followers</span>
							</li>
							<li>
								530
								<span>Following</span>
							</li>
						</ul>
					</div>
				</div>
				
			

		

		
		<!-- FIN INFO USUARIO -->
		</div>

		
	
	<!-- FIN HOME CONTENT -->
	</div>




</body>




          </div>

          </div>
	<script type="text/javascript" src = js/menuJs.js></script>
	<script type="text/javascript" src = js/caracteres.js></script>

</html>
