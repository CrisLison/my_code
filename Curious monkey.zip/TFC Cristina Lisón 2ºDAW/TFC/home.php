
<?php

session_start();
include ('lib/config.php');
include ('lib/side.php');

if (!isset($_SESSION['cuenta'])){

	header("Location: registro.php");

}

?>	


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="styles/menu.css">
	<link rel="stylesheet" type="text/css" href="styles/screechBox.css">
	<link rel="stylesheet" type="text/css" href="styles/publiStyle.css">
	<title>Home</title>
	<link rel="shortcut icon" href="imgs/logo.png">
	<!-- LINK IMPORTACIÓN ICONOS DESDE BOXICONS-->
	<link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>


	


</head>
<body style="overflow-y: scroll; background-color: rgb(255, 255, 255, .99);">
	<div class="menuLateral">
		<?php
			barraLateral();
		  ?>
	</div>
	
	<div class="homeContent">


		<div class="texto">

					<div>
							<?php 
								navBar('Home');
							?>
					</div>

						


					<div class="screechBox">
						<form method="POST" enctype="multipart/form.data">
							<div class="screechBox_Input">
								<img src="imgs/<?php echo $_SESSION['avatar'];?>" class="screechProfile">
								<input name="publicacion" id="publicacion" placeholder="What's happening?" required maxlength="90">
							
							</div>
							<div class="caracteresScreech">
								<p class="caracteres" id="maximo"></p>
							</div>
								
							<!-- <input type="file" placeholder="Add image" name ="foto" id="foto" class="screechImage" data-multiple-caption = "{count} files selected"> -->
							<button type="submit" name = "publicar" id = "publicar" class="screechButton">Screech!</button>
						</form>
					</div>

					<!----------------REALIZAR PUBLICACIÓN--------------------->
					<?php 

				$connect = conn();

				

				if (isset($_POST['publicar'])) 

				{

					$publicacion = ($_POST['publicacion']);

					
					$user = $_SESSION['id'];
					date_default_timezone_set('UTC');
					$fechaPubli = date("m.d.y");


					$result = mysqli_query($connect, "SHOW TABLE STATUS FROM tfc like 'publicaciones'");
					$data = mysqli_fetch_assoc($result);	
					$next_increment = $data['Auto_increment'];

					$alea = substr(strtoupper(md5(microtime(true))), 0,12);
					$code = $next_increment.$alea;

					$subir = mysqli_query($connect, "INSERT INTO publicaciones (usuario, fecha, contenido, comentarios) VALUES ('$user', '$fechaPubli', '$publicacion', 1 )");
					
					if($subir){
						echo ('<script>window.location = "home.php"</script>');
					}	
					


				}
				
				mysqli_close($connect);
			?>

			<!--- SCROLL ---->
					
					

					<div class="publicacioneScroll" >
						
							<?php require_once 'lib/publicaciones.php'; ?>

						
					</div>
					
			  

				
					


		</div>

		<div  >
			<div class="perfilSugerencias"style="float: right; position: fixed; width: 20%; margin-left:  15px;" >


					<div class="perfilLateral" style="float: right; position: fixed;">
						<div>
							<img src="imgs/<?php echo $_SESSION['avatar'];?>" class="fotoPerfilLateral" >
							<div class="circulo"></div>

					
							<div class = "nombresLateral" >
								
									<span><?php echo $_SESSION['nombre']; ?></span>
									
									<span class="nCuentaLateral"><?php echo '@'.$_SESSION['cuenta']; ?></span>
							
						
							</div>

							
						</div>

					</div>
					<!-- CUENTAS SUGERIDAS -->
					<div class = "linea" style="float: right; position: fixed; width: 18% !important; margin-top: 155px;"></div>
					<div class="sugerencias" style="float: right; position: fixed; margin-top: 175px;">
						<span >Sugerencias</span>
					</div>

			</div>
		</div>
	
	<!-- FIN HOME CONTENT -->
	</div>
	


</body>
	<script type="text/javascript" src = js/menuJs.js></script>
	<script type="text/javascript" src = js/caracteres.js></script>
	

</html>