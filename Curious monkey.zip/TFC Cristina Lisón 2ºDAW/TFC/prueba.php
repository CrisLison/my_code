<?php

session_start();
include ('lib/config.php');
include ('lib/side.php');

if (!isset($_SESSION['cuenta'])){

	header("Location: regitro.php");

}
$codUser = 0;

if (isset($_GET['cod'])){

	$codUser = ($_GET['cod']);
}

?>	
	<?php require_once 'lib/publicaciones.php'; ?>
	<link rel="stylesheet" type="text/css" href="styles/publiStyle.css">

