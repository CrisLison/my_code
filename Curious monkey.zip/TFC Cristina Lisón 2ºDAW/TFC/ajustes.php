
<?php

session_start();
include ('lib/config.php');
include ('lib/side.php');

if (!isset($_SESSION['cuenta'])){

	header("Location: regitro.php");

}

?>	


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" type="text/css" href="styles/menu.css">
	<link rel="stylesheet" type="text/css" href="styles/ajustes.css">
	<link rel="stylesheet" type="text/css" href="styles/publiStyle.css">
		<link rel="stylesheet" type="text/css" href="styles/profile.css">
	<title>Settings</title>
	<link rel="shortcut icon" href="imgs/logo.png">
	<!-- LINK IMPORTACIÓN ICONOS DESDE BOXICONS-->
	<link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
	

	



</head>
<body>

	<div class="menuLateral">
		<?php
			barraLateral();
		  ?>
	</div>
	<div class="homeContent">
		
		
		<div class="container" style="overflow-y: scroll;">

			<div class="cajaIzq" style="position: fixed;">
				<nav>

					<!-- PERFIL -->
					<a onclick="tabs(0)" class="tab active">
						<i><img src= "imgs/platano.png" height="15px" width="15px"></i>
					</a>

					<!-- CUENTA -->

					<a onclick="tabs(1)" class="tab">
						<i class='bx bxs-lock-alt'></i>
					</a>

				</nav>
			</div>

			<div class="cajaDch" >

				<!-- PERFIL -->
				<div class="profile tabShow">
					<h1>My profile</h1>

					<!-- NOMBRE -->
					
					<h2>My new profile name</h2>
					<form method="POST" action = "">
						<input type="text" class="inputs"  id="input1" name="input1" required maxlength="12" onkeyup="caracteres('1'); ">
						<span class="counter" id="counter1"> 12 </span><br>
						<button class="btnAjustes" id="cambioNombre" name="cambioNombre"><span>Change</span></button>

					</form>

					<!-- BIO -->

					<h2>My new bio</h2>

					<form method="POST">
						<input type="text" class="inputs" id = "input2" name="input2" required maxlength="120" onkeyup="caracteres('2')";>
						<span class="counter" id="counter2"> 120 </span><br>
						<button class="btnAjustes" id="newBio" name="newBio"><span>Change</span></button>
					</form>
				</div>


				<!-- CUENTA -->
				<div class="account tabShow">

					

					<!-- CONTRASEÑAS -->
					<h1>My passwords</h1>


					<h1 class="subtitulo">Change password</h1>
					<form method="POST">
						<h2>Write the new password</h2>
						<input type="text" class="inputs" required id="pwd1" name="pwd1" maxlength="16" minlength="8">
						<span class="counter">  </span><br>
					
						<h2>Confirm new password</h2>
						<input type="text" class="inputs" required id="pwd2" name="pwd2" maxlength="16" minlength="8">
						<br>

						<h2>Write the old password to confirm</h2>
						<input type="text" class="inputs" required id = "pwd3" name="pwd3">
						<br>
						<button class="btnAjustes" id="cambioPwd" name="cambioPwd" onclick="comprobar()"><span>Change</span></button>
					</form>


				
				</div>
				
			</div>
		</div>
	</div>


</body>
	
	<script type="text/javascript" src = js/menuJs.js></script>
	<script type="text/javascript" src = js/cambio.js></script>	

	<script>
		function comprobar(){

		contrasena = document.getElementById('pwd1').value;
		contrasena2 = document.getElementById('pwd2').value;

		var expPwd = /^[A-Za-z0-9!]/;


		if (expPwd.test(contrasena) == true){

			if(contrasena1 == contrasena2){
				
				<?php
				$connect = conn();
				$id = $_SESSION['id'];
				$pwd3 = $_POST['pwd3'];

				if(isset($_POST['cambioPwd'])){
					$contrasena = ($_POST['pwd1']);

						$comprobarPWD = mysqli_query($connect, "SELECT contrasena FROM usuarios WHERE id_use = '$id'");
						

						$use1 = mysqli_fetch_array($comprobarPWD);

					if($pwd3 == $use1['contrasena']){

						$cambioPwd = mysqli_query($connect, "UPDATE usuarios SET contrasena = '$contrasena' WHERE id_use = '$id'");	
			
					}
				
						
				}
				?>




			} else{
				alert("The new passwords doesn't match");
			}

			//CAMBIO PWD
			
		} else{
			alert("The new password doesn't serve");
		} 
	}

/*
		$(".tab").click(function(){
			$(this).addClass("active").siblings().removeClass("active");
		});
		*/
	</script>


	<?php

	$connect = conn();

		
		$id = $_SESSION['id'];

		//CAMBIO NOMBRE USUARIO

		if(isset($_POST['cambioNombre'])){

		$newName = ($_POST['input1']);
		$newName = strip_tags($_POST['input1']);
		$newName = trim($_POST['input1']);
		
	

		$cambioNombre = mysqli_query($connect, "UPDATE usuarios SET nombre = '$newName' WHERE id_use = '$id'");		

		

		} else {
	
	}



		//CAMBIO BIO

		if(isset($_POST['newBio'])){

		$newBio = ($_POST['input2']);
		$newBio = strip_tags($_POST['input2']);
		
	

		$cambioBio = mysqli_query($connect, "UPDATE usuarios SET bio = '$newBio' WHERE id_use = '$id'");		
	
		} else {
	
	}

	
		
		
		


		mysqli_close($connect);
		
	?>


</html>


