<?php

session_start();
include ('lib/config.php');

if (isset($_SESSION['cuenta'])){

	header("Location: home.php");

}

?>	


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- Bibliotecas externas-->
	<link href='https://unpkg.com/boxicons@2.1.2/css/boxicons.min.css' rel='stylesheet'>
	

	<link rel="shortcut icon" href="imgs/logo.png">
	<link rel="stylesheet" type="text/css" href="styles/loginRegistro.css">
	<title>Curious monkey</title>
</head>
<body>
	<div class="container">
		<div class="forms-container">

			<div class="signin-signup">

				<!---------- LOGIN ---------->

				<form class="sign-in-form" method="POST" action="">
					<h2 class="title">Sign in</h2>

					<div class="input-field">
						<i class='bx bxs-user-circle'></i>
						<input type="text" name="username" id="username" placeholder="Account name" required>
					</div>

					<div class="input-field">
						<i class='bx bxs-lock-alt' ></i>
						<input type="password" name="pwdLogin" id="pwdLogin" placeholder="Password" required>
					</div>

					<button type="submit" value="send" id = "login" name="login" class="btn solid">Login</button>

					

				</form>

				<!---------- REGISTRO ---------->

				<form class="sign-up-form" action="" method="POST">
					<h2 class="title">Sign up</h2>

					<div class="input-field">
						<i class='bx bxs-user-circle'></i>
						<input type="text" name="nombreRegistro" id="nombreRegistro" placeholder="Username" required maxlength="12" minlength="3">
					</div>

					<div class="input-field">
						<i class='bx bx-meh-blank'></i>
						<input type="text" name="usuarioRegistro" id="usuarioRegistro" placeholder="Account name" required maxlength="12" minlength="3">
					</div>

					<div class="input-field">
						<i class='bx bxs-envelope' ></i>
						<input type="email" name="emailRegistro" id="emailRegistro" placeholder="Email" required>
					</div>

					<div class="input-field">
						<i class='bx bxs-lock-alt' ></i>
						<input type="password" name="contrasenaRegistro" id="contrasenaRegistro" placeholder="Password" required  required maxlength="16" minlength="8">
					</div>

					<div class="input-field">
						<i class='bx bxs-lock-alt' ></i>
						<input type="password" name="repcontrasenaRegistro" id="repcontrasenaRegistro" placeholder="Repeat password" required>
					</div>
					<button type="submit" value="send" name="registrar" id="registrar" class="btn solid" onclick="comprobar()">Register</button>

				
				</form>

				<!---------------------------------------------------------------------------------->

	<?php
	
		$connect = conn();


		// --------------------------------- LOGIN ---------------------------------

		if(isset($_POST['login'])){

			$usuarioLogin = ($_POST['username']);
			$usuarioLogin = strip_tags($_POST['username']);
			$usuarioLogin = trim($_POST['username']);

			$pwdLogin = ($_POST['pwdLogin']);
			$pwdLogin = strip_tags($_POST['pwdLogin']);
			$pwdLogin = trim(md5($_POST['pwdLogin']));
				
			$query = mysqli_query($connect, "SELECT * FROM usuarios WHERE usuario = '$usuarioLogin' AND contrasena = '$pwdLogin'");
			
			
			$rows = mysqli_num_rows($query);

			if ($rows == 1) {

				$row = mysqli_fetch_array($query);
				 
					if($usuarioLogin = $row['usuario'] && $pwdLogin = $row['contrasena']){

						$_SESSION['cuenta'] = $row['usuario'];
						$_SESSION['id'] = $row['id_use'];
						$_SESSION['nombre'] = $row['nombre'];
						$_SESSION['avatar'] = $row['avatar'];

						header("Location: home.php");
					}
						

				} else {
					echo (
						'<script language="javascript">
							alert("Something went wrong..");
						</script>'
					);

					
				} 
				
			}
		

		mysqli_close($connect);


	
		
			

			?>
		
			</div>	

		</div>

		<div class="panels-container">

			<div class="panel left-panel">
				<div class="content">
					<h3>New here?</h3>
					<p>Join us!</p>
					<button class="btn transparent" id="sign-up-btn">Sign up</button>
				</div>
				<img src="imgs/login.svg" class="image">
			</div>

				<div class="panel right-panel">
				<div class="content">
					<h3>One of us?</h3>
					<p>Come in!</p>
					<button class="btn transparent" id="sign-in-btn" >Sign in</button>
				</div>
				<img src="imgs/signup.svg" class="image">
			</div>

		</div>
	</div>
</body>
<script type="text/javascript" src="js/loginRegistro.js"></script>

<script type="text/javascript">

	function comprobar(){

		var expNombre = /^[A-Za-z0-9]/;
		
		var expUser = /^[A-Za-z0-9_]/;
		var expPwd = /^[A-Za-z0-9!]/;

		var nombre = document.getElementById('nombreRegistro').value;
		var usuario = document.getElementById('usuarioRegistro').value;
		
		var contrasena = document.getElementById('contrasenaRegistro').value;

		
		if(expNombre.test(nombre) == true){

			if(expUser.test(usuario) == true){
				
				if (expPwd.test(contrasena) == true){

					<?php

						// --------------------------------- REGISTRO PHP---------------------------------

						$connect = conn();

						if(isset($_POST['registrar'])){
							$nombre = ($_POST['nombreRegistro']);
							$email = ($_POST['emailRegistro']);
							$usuario = ($_POST['usuarioRegistro']);
							$contrasena = (md5($_POST['contrasenaRegistro']));
							$repcontrasena = (md5($_POST['repcontrasenaRegistro']));
							$fechaReg = date("d/m/y");

							
							
							$comprobarUsuario = mysqli_query($connect, "SELECT usuario FROM usuarios WHERE usuario = '$usuario'");
							$comprobarEmail = mysqli_query($connect, "SELECT email FROM usuarios WHERE email = '$email'");

							
							
							if($comprobarUsuario -> num_rows > 0){				

								?> alert("El nombre de usuario ya está en uso"); <?php

							} else {

								if ($comprobarEmail -> num_rows > 0) {

									?> alert("El correo indicado ya existe"); <?php
									

								} else {
									
									if($contrasena != $repcontrasena){
										
											?> alert("Las contraseñas no coinciden"); <?php


											
									} else {

										$insertar =  mysqli_query($connect, "INSERT INTO usuarios (nombre, email, usuario, contrasena, fecha_reg, avatar) VALUES ('$nombre', '$email', '$usuario', '$contrasena', '$fechaReg', 'default.png')");
										if($insertar){
											header("Refresh: 1.2; url = registro.php");
										}
									}

								}
							}
							


							
							
						} 

						mysqli_close($connect);





					?>


				} else{
					alert("La contraseña no cumple con los requisitos (La contraseña debe tener al entre 8 y 16 caracteres, al menos un dígito, al menos una minúscula y al menos una mayúscula. Puede contener exclamaciones");
				}

			} else {
				alert("El nombre de cuenta no cumple con los requisitos (de 3 hasta 12 caracteres alfanuméricos incluyendo guinoes bajos)");
			}

		
		} else {
			alert("El nombre de usuario no cumple con los requisitos (de 3 hasta 12 caracteres alfanuméricos)");


		}
		
	}
	
</script>

</html>